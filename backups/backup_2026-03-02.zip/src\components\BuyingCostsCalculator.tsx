import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Calculator, Info, Euro, Percent, FileText } from 'lucide-react';

interface CalculationResult {
  stampDuty: number;
  notaryFees: number;
  searchFees: number;
  aipFee: number;
  totalBuyerCosts: number;
  totalPrice: number;
  percentageOfPrice: number;
}

export const BuyingCostsCalculator = () => {
  const [price, setPrice] = useState<number>(500000);
  const [isFirstBuy, setIsFirstBuy] = useState(false);
  const [isPrimaryResidence, setIsPrimaryResidence] = useState(true);
  const [needsAIP, setNeedsAIP] = useState(false);
  const [result, setResult] = useState<CalculationResult | null>(null);

  useEffect(() => {
    calculate();
  }, [price, isFirstBuy, isPrimaryResidence, needsAIP]);

  const calculate = () => {
    // Stamp Duty: standard 5%
    // Primary residence: 3.5% on first 200k, 5% on balance
    let stampDuty = 0;
    if (isPrimaryResidence) {
      const firstTier = Math.min(price, 200000);
      const balance = Math.max(0, price - 200000);
      stampDuty = (firstTier * 0.035) + (balance * 0.05);
    } else {
      stampDuty = price * 0.05;
    }

    // Notary Fees: approx 1.25%
    const notaryFees = price * 0.0125;
    
    // Search Fees: approx 500
    const searchFees = 500;
    
    // AIP Fee: 233
    const aipFee = needsAIP ? 233 : 0;

    const totalBuyerCosts = stampDuty + notaryFees + searchFees + aipFee;

    setResult({
      stampDuty,
      notaryFees,
      searchFees,
      aipFee,
      totalBuyerCosts,
      totalPrice: price + totalBuyerCosts,
      percentageOfPrice: (totalBuyerCosts / price) * 100
    });
  };

  return (
    <div className="glass-card rounded-[2rem] border border-gold/20 overflow-hidden">
      <div className="p-8 border-b border-white/10 bg-white/5">
        <div className="flex items-center gap-3 mb-2">
          <Calculator className="text-gold" size={24} />
          <h3 className="text-2xl font-serif">Buying Costs Calculator</h3>
        </div>
        <p className="text-white/40 text-sm">Estimate the total acquisition costs for property in Malta (2026 rates).</p>
      </div>

      <div className="p-8 grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Inputs */}
        <div className="space-y-8">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-white/40 mb-4 flex justify-between">
              Property Price
              <span className="text-gold">€{price.toLocaleString()}</span>
            </label>
            <input 
              type="range" 
              min="100000" 
              max="5000000" 
              step="10000"
              value={price}
              onChange={(e) => setPrice(parseInt(e.target.value))}
              className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-gold"
            />
            <div className="flex justify-between mt-2 text-[10px] text-white/20 font-bold">
              <span>€100k</span>
              <span>€5M</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button 
              onClick={() => setIsPrimaryResidence(!isPrimaryResidence)}
              className={`p-4 rounded-2xl border transition-all text-left ${isPrimaryResidence ? 'bg-gold/10 border-gold text-gold' : 'bg-white/5 border-white/10 text-white/40 hover:border-white/20'}`}
            >
              <div className="text-[10px] font-bold uppercase tracking-widest mb-1">Primary Residence</div>
              <div className="text-xs">{isPrimaryResidence ? 'Reduced Stamp Duty' : 'Standard Rate'}</div>
            </button>

            <button 
              onClick={() => setNeedsAIP(!needsAIP)}
              className={`p-4 rounded-2xl border transition-all text-left ${needsAIP ? 'bg-gold/10 border-gold text-gold' : 'bg-white/5 border-white/10 text-white/40 hover:border-white/20'}`}
            >
              <div className="text-[10px] font-bold uppercase tracking-widest mb-1">Non-EU / AIP Required</div>
              <div className="text-xs">{needsAIP ? '+ €233 Permit Fee' : 'No Permit Needed'}</div>
            </button>
          </div>

          <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex gap-4">
            <Info className="text-gold shrink-0" size={20} />
            <p className="text-[10px] text-white/40 leading-relaxed">
              * This is an estimate. Actual notary fees and searches may vary. Stamp duty exemptions for first-time buyers are not included in this calculation.
            </p>
          </div>
        </div>

        {/* Results */}
        <div className="bg-luxury-black/40 rounded-3xl p-8 border border-white/10 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5">
            <Euro size={120} />
          </div>

          <h4 className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-8">Cost Breakdown</h4>
          
          <div className="space-y-6 mb-8">
            <div className="flex justify-between items-center">
              <span className="text-sm text-white/60 flex items-center gap-2">
                <Percent size={14} className="text-gold/40" /> Stamp Duty
              </span>
              <span className="text-lg font-serif">€{result?.stampDuty.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-white/60 flex items-center gap-2">
                <FileText size={14} className="text-gold/40" /> Notary & Searches
              </span>
              <span className="text-lg font-serif">€{(result!?.notaryFees + result!?.searchFees).toLocaleString()}</span>
            </div>
            {needsAIP && (
              <div className="flex justify-between items-center">
                <span className="text-sm text-white/60">AIP Permit Fee</span>
                <span className="text-lg font-serif">€233</span>
              </div>
            )}
          </div>

          <div className="pt-8 border-t border-white/10">
            <div className="flex justify-between items-end mb-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-gold">Total Extra Costs</span>
              <span className="text-3xl font-serif text-gold">€{result?.totalBuyerCosts.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-[10px] font-bold text-white/20 uppercase tracking-widest">
              <span>Approx. {result?.percentageOfPrice.toFixed(2)}% of price</span>
            </div>
          </div>

          <div className="mt-8 p-6 bg-gold rounded-2xl text-luxury-black">
            <div className="text-[10px] font-bold uppercase tracking-widest mb-1 opacity-60">Total Investment</div>
            <div className="text-2xl font-serif font-bold">€{result?.totalPrice.toLocaleString()}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
