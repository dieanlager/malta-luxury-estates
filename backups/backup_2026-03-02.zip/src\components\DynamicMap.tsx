import React, { useState, useMemo } from 'react';
import { Map, Marker, Popup, NavigationControl, FullscreenControl } from 'react-map-gl/mapbox';
import 'mapbox-gl/dist/mapbox-gl.css';
import { PROPERTIES } from '../constants';
import { Property } from '../types';
import { Home, Bath, Square, ArrowRight, X } from 'lucide-react';
import { Link } from 'react-router-dom';

const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_TOKEN || 'pk.eyJ1IjoiYmVhdHdiIiwiYSI6ImNtN2FmN3R3ZDAxM3Yya3B5bmN5bmN5bmMifQ.example_token'; // Placeholder

export const DynamicMap = () => {
    const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);

    const propertiesWithCoords = useMemo(() =>
        PROPERTIES.filter(p => p.lat && p.lng),
        []
    );

    return (
        <div className="w-full h-[600px] rounded-[3rem] overflow-hidden border border-white/10 shadow-2xl relative group/map">
            <Map
                initialViewState={{
                    latitude: 35.9122,
                    longitude: 14.5042,
                    zoom: 11
                }}
                style={{ width: '100%', height: '100%' }}
                mapStyle="mapbox://styles/mapbox/dark-v11"
                mapboxAccessToken={MAPBOX_TOKEN}
            >
                <NavigationControl position="top-right" />
                <FullscreenControl position="top-right" />

                {propertiesWithCoords.map(property => (
                    <Marker
                        key={property.id}
                        latitude={property.lat!}
                        longitude={property.lng!}
                        anchor="bottom"
                        onClick={e => {
                            e.originalEvent.stopPropagation();
                            setSelectedProperty(property);
                        }}
                    >
                        <div className="group cursor-pointer">
                            <div className="bg-gold text-luxury-black px-3 py-1 rounded-full text-xs font-bold shadow-lg transform transition-transform group-hover:scale-110 border border-white/20">
                                €{(property.price / 1000000).toFixed(1)}M
                            </div>
                            <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px] border-t-gold mx-auto" />
                        </div>
                    </Marker>
                ))}

                {selectedProperty && (
                    <Popup
                        latitude={selectedProperty.lat!}
                        longitude={selectedProperty.lng!}
                        anchor="bottom"
                        onClose={() => setSelectedProperty(null)}
                        closeButton={false}
                        maxWidth="320px"
                        className="property-popup"
                    >
                        <div className="bg-luxury-black text-white rounded-2xl overflow-hidden border border-gold/30 shadow-2xl">
                            <div className="relative aspect-video">
                                <img
                                    src={selectedProperty.images[0]}
                                    alt={selectedProperty.title}
                                    className="w-full h-full object-cover"
                                />
                                <button
                                    onClick={() => setSelectedProperty(null)}
                                    className="absolute top-2 right-2 bg-black/50 p-1 rounded-full hover:bg-black/80 transition-colors"
                                >
                                    <X size={16} />
                                </button>
                            </div>
                            <div className="p-4">
                                <div className="flex justify-between items-start mb-2">
                                    <h3 className="font-serif text-lg leading-tight">{selectedProperty.title}</h3>
                                    <span className="text-gold font-bold">€{(selectedProperty.price / 1000000).toFixed(1)}M</span>
                                </div>
                                <p className="text-white/50 text-[10px] uppercase tracking-wider mb-4">{selectedProperty.locationName}</p>

                                <div className="flex gap-4 mb-4 border-t border-white/5 pt-4">
                                    <div className="flex items-center gap-1.5 text-xs text-white/70">
                                        <Home size={12} className="text-gold" />
                                        <span>{selectedProperty.beds}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5 text-xs text-white/70">
                                        <Bath size={12} className="text-gold" />
                                        <span>{selectedProperty.baths}</span>
                                    </div>
                                    <div className="flex items-center gap-1.5 text-xs text-white/70">
                                        <Square size={12} className="text-gold" />
                                        <span>{selectedProperty.sqm}m²</span>
                                    </div>
                                </div>

                                <Link
                                    to={`/properties/${selectedProperty.id}`}
                                    className="flex items-center justify-center gap-2 w-full py-2 bg-gold/10 hover:bg-gold/20 text-gold rounded-xl transition-all text-xs font-bold uppercase tracking-widest border border-gold/20"
                                >
                                    View Details <ArrowRight size={14} />
                                </Link>
                            </div>
                        </div>
                    </Popup>
                )}
            </Map>

            {/* Decorative Label */}
            <div className="absolute top-8 left-8 pointer-events-none">
                <div className="bg-luxury-black/80 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/10 shadow-xl">
                    <p className="text-[10px] uppercase tracking-[0.2em] font-bold text-gold mb-1">Interactive</p>
                    <h2 className="text-2xl font-serif text-white">Live Market View</h2>
                </div>
            </div>
        </div>
    );
};
