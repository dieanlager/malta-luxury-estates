# Malta Luxury Estates - Programmatic SEO & Data Strategy

## 1. Core Strategy: Programmatic SEO (pSEO)
The goal is to build a high-traffic engine using Malta's unique geographic structure (68 local councils) combined with property types and investment insights.

### Hierarchy
1. **Island**: Malta, Gozo, Comino.
2. **Council/City**: 68 local councils (Sliema, St. Julians, Valletta...).
3. **Area/Neighbourhood**: Paceville, Qawra, Tigné Point, Madliena...
4. **Property Type**: Apartments, Penthouses, Villas, Houses of Character, Maisonettes, Duplexes.

### URL Silos
- `/properties/{city-slug}`: City-level overview with market stats.
- `/properties/{city-slug}/{type-slug}`: Specific property type in a specific city (e.g., `luxury-villas-in-mellieha`).
- `/invest/{city-slug}`: Investment-focused guides per locality.
- `/guides/{topic-slug}`: Global knowledge hub (Taxes, Residency, Buying Process).

---

## 2. Database Schema (Target)

### Locations Table
Stores geographic and descriptive data for councils and areas.
- `id`, `slug`, `name_en`, `island`, `region`, `location_type`, `population`, `area_km2`, `lat`, `lng`, `is_luxury_hub`, `short_desc`, `long_intro`.

### Properties Table
Stores the actual listings (synced from agency feeds).
- `id`, `external_id`, `agency_id`, `location_id`, `listing_type` (sale/rent), `property_type`, `status`, `price`, `bedrooms`, `bathrooms`, `area_m2`, `has_sea_view`, `is_luxury_tag`, `lat`, `lng`, `main_image_url`.

### Location Stats Table
Aggregated data for "Market Snapshots" (updated via daily cron).
- `location_id`, `listings_sale_count`, `listings_rent_count`, `median_price_sale`, `median_price_rent`, `avg_price_sale`, `avg_price_rent`, `last_calculated_at`.

---

## 3. SEO Templates

### City Pages
- **Title**: `{City} Property for Sale & Rent in {Island} | Malta Luxury Estates`
- **Description**: `Discover curated properties in {City}, {Island} – seafront apartments, penthouses and villas from top local agencies. Explore prices and investment opportunities.`

### Type + City Pages
- **Title**: `{TypePlural} for Sale in {City}, {Island} | Malta Luxury Estates`
- **Description**: `Browse curated {typePlural} for sale in {City}, {Island}. Verified listings from leading agencies with seafront and exclusive options.`

---

## 4. Implementation Roadmap (Updated 2026-03-02)

1.  **[COMPLETED] Sprint 1**: Build `Location` table and seed with top 15 luxury hubs. (Live metadata system handles this).
2.  **[COMPLETED] Sprint 2**: Implement `/properties/[citySlug]` dynamic routing with `MarketSnapshot` component. 
3.  **[IN PROGRESS] Sprint 3**: Connect real agency XML/JSON feeds to populate `Properties` table (Currently using High-Fidelity Mock data).
4.  **[COMPLETED] Sprint 4**: Launch Knowledge Hub (`/guides`) with 21 curated deep-dive articles and pSEO optimization.

---

## 5. Technical Stack & SEO Highlights
- **Tech**: React 19, Vite, Tailwind CSS 4, Mapbox GL.
- **pSEO Engine**: Custom metadata hook (`usePageMeta`) with JSON-LD schema support.
- **Components**: Dynamic Map, Market Snapshots, Property Filters, Knowledge Hub.
- **SEO Health**: 100/100 (Sitemap, Robots, Schema, Meta tags all implemented).

## 6. Next Steps (March 2026)
- **Supabase Production Sync**: Transition from mock data to real database population.
- **Mapbox Optimization**: Finalize token configuration and custom tile styles.
- **Lead Generation**: Refine contact modals and analytics tracking.
- **Expansion**: Consider adding multi-language support (IT/PL).
