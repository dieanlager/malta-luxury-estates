import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft, Calendar, Clock, Share2, Bookmark, ChevronRight } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { getArticleBySlug, getArticles } from '../lib/data';
import { Article } from '../types';
import { Breadcrumb } from '../components/Breadcrumb';
import { generateArticleSchema } from '../lib/seo/schemas';
import { usePageMeta } from '../lib/seo/meta';

export const ArticlePage = () => {
  const { slug } = useParams<{ slug: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!slug) return;
      const data = await getArticleBySlug(slug);
      if (data) {
        setArticle(data);
        const all = await getArticles();
        setRelatedArticles(all.filter(a => a.slug !== slug).slice(0, 2));
      }
      setLoading(false);
    };
    fetchData();
    window.scrollTo(0, 0);
  }, [slug]);

  // SEO – must be called before any conditional returns (React hook rules)
  usePageMeta({
    title: article ? `${article.title} | Malta Luxury Estates` : 'Insights | Malta Luxury Estates',
    description: article?.metaDescription || article?.excerpt || 'Expert guides and analysis for Malta real estate investors.',
    canonicalPath: article ? `/insights/${article.slug}` : '/insights',
    ogType: 'article',
    ogImage: article?.image,
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-luxury-black flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-gold/20 border-t-gold rounded-full animate-spin" />
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen bg-luxury-black flex flex-col items-center justify-center p-6 text-center">
        <h1 className="text-4xl font-serif mb-4">Article Not Found</h1>
        <Link to="/insights" className="gold-gradient text-luxury-black px-8 py-3 rounded-full text-xs font-bold uppercase tracking-widest">
          Back to Insights
        </Link>
      </div>
    );
  }

  const schemaData = generateArticleSchema(article);

  return (
    <>
      <script type="application/ld+json">
        {JSON.stringify(schemaData)}
      </script>
      <main className="min-h-screen bg-luxury-black">
        {/* Article Hero */}
        <header className="relative h-[70vh] min-h-[600px] overflow-hidden">
          <img
            src={article.image}
            alt={article.title}
            className="absolute inset-0 w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-luxury-black via-luxury-black/60 to-transparent" />

          <div className="absolute inset-0 flex items-end pb-20">
            <div className="max-w-7xl mx-auto px-6 w-full">
              <div className="mb-6">
                <Breadcrumb items={[
                  { label: 'Home', href: '/' },
                  { label: 'Insights', href: '/insights' },
                  { label: article.title },
                ]} />
              </div>

              <div className="max-w-4xl">
                <div className="flex items-center gap-4 mb-6">
                  <span className="px-4 py-1 bg-gold text-luxury-black text-[10px] font-bold uppercase tracking-widest rounded-full">
                    {article.category}
                  </span>
                  <div className="flex items-center gap-2 text-white/60 text-xs">
                    <Calendar size={14} /> {article.date}
                  </div>
                  <div className="flex items-center gap-2 text-white/60 text-xs">
                    <Clock size={14} /> {article.readTime}
                  </div>
                </div>
                <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif mb-8 leading-tight">
                  {article.title}
                </h1>
              </div>
            </div>
          </div>
        </header>

        {/* Content Section */}
        <section className="py-24">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col lg:flex-row gap-20">
              {/* Main Content */}
              <article className="flex-1">
                <div className="prose prose-invert prose-gold max-w-none">
                  <div className="markdown-body">
                    <ReactMarkdown>{article.content}</ReactMarkdown>
                  </div>
                </div>

                {/* Share & Actions */}
                <div className="mt-20 pt-10 border-t border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-6">
                    <button className="flex items-center gap-2 text-white/40 hover:text-gold transition-colors text-xs uppercase tracking-widest font-bold">
                      <Share2 size={16} /> Share Article
                    </button>
                    <button className="flex items-center gap-2 text-white/40 hover:text-gold transition-colors text-xs uppercase tracking-widest font-bold">
                      <Bookmark size={16} /> Save for Later
                    </button>
                  </div>
                </div>
              </article>

              {/* Sidebar */}
              <aside className="lg:w-80 shrink-0">
                <div className="sticky top-32 space-y-12">
                  {/* Related Articles */}
                  <div>
                    <h3 className="text-xl font-serif mb-8">Related Guides</h3>
                    <div className="space-y-8">
                      {relatedArticles.map(rel => (
                        <Link key={rel.slug} to={`/insights/${rel.slug}`} className="group block">
                          <div className="aspect-video rounded-2xl overflow-hidden mb-4 border border-white/10">
                            <img src={rel.image} alt={rel.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" referrerPolicy="no-referrer" />
                          </div>
                          <h4 className="font-serif text-lg group-hover:text-gold transition-colors line-clamp-2">{rel.title}</h4>
                        </Link>
                      ))}
                    </div>
                  </div>

                  {/* Newsletter Box */}
                  <div className="glass-card p-8 rounded-3xl border border-gold/20">
                    <h3 className="text-xl font-serif mb-4">Market Intelligence</h3>
                    <p className="text-sm text-white/40 mb-6 leading-relaxed">
                      Get the latest regulatory updates and investment opportunities delivered to your inbox.
                    </p>
                    <input
                      type="email"
                      placeholder="Email address"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm mb-4 outline-none focus:border-gold"
                    />
                    <button className="w-full gold-gradient text-luxury-black py-3 rounded-xl text-[10px] font-bold uppercase tracking-widest">
                      Subscribe
                    </button>
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </section>

        {/* Bottom CTA */}
        <section className="py-24 bg-white/[0.02] border-t border-white/5">
          <div className="max-w-7xl mx-auto px-6 text-center">
            <h2 className="text-3xl md:text-5xl font-serif mb-8">Ready to explore the market?</h2>
            <div className="flex flex-wrap justify-center gap-6">
              <Link to="/properties/all" className="gold-gradient text-luxury-black px-10 py-4 rounded-full text-xs font-bold uppercase tracking-widest hover:scale-105 transition-transform shadow-xl">
                View All Properties
              </Link>
              <Link to="/" className="px-10 py-4 border border-white/10 rounded-full text-xs font-bold uppercase tracking-widest hover:border-gold transition-all">
                Return Home
              </Link>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};
